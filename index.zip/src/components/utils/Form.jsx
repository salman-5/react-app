import {
    Radio,
    Card,
    List,
    ListItem,
    ListItemPrefix,
    Typography
} from "@material-tailwind/react";
import Input, { getCountries, getCountryCallingCode } from 'react-phone-number-input/input';
import en from 'react-phone-number-input/locale/en.json';
import { useState } from "react";
import PhoneInputWithCountrySelect from "react-phone-number-input";
import PhoneInput from 'react-phone-number-input'

export default function Form(params) {
    const CountrySelect = ({ value, onChange, labels, ...rest }) => (
        <select {...rest} value={value} onChange={(event) => onChange(event.target.value || undefined)}>
            <option value="">{labels.ZZ}</option>
            {getCountries().map((country) => (
                <option key={country} value={country}>
                    {labels[country]} +{getCountryCallingCode(country)}
                </option>
            ))}
        </select>
    );
    const [phoneNumber, setPhoneNumber] = useState();
    const [country, setCountry] = useState();
    const [value, setValue] = useState()
    return (

        <>

            <form action="#" class="space-y-8 m-8 p-8 bg-slate-500 rounded-[30px] justify-center">
                <div className="grid grid-cols-2 gap-5">
                    <div className="flex flex-col gap-3">

                        <div>
                            <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Name</label>
                            <input type="text" id="name" class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 shadow-sm focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500 dark:shadow-sm-light" placeholder="Name" required />
                        </div>
                        <div>
                            <label for="email" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Your email</label>
                            <input type="email" id="email" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500 dark:shadow-sm-light" placeholder="email" required />
                        </div>
                        <div>
                            <label for="Mobile Number" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Mobile Number</label>
                            {/* <input type="email" id="email" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500 dark:shadow-sm-light" placeholder="name@flowbite.com" required /> */}

                            <div className="flex flex-col">
                                <PhoneInputWithCountrySelect
                                    containerClass=""
                                    international
                                    defaultCountry="AE"
                                    onChange={setValue}
                                    placeholder={"a"}
                                    numberInputProps={{
                                        className: 'rounded-md px-4  w-full focus:outline-none shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500 dark:shadow-sm-light' // my Tailwind classes
                                    }}
                                    countrySelectProps={

                                        {
                                            className: "flex flex-col shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500 dark:shadow-sm-light"
                                        }}
                                    // flagComponent={
                                    //     {

                                    //         flags: {
                                    //             className: "y-10"
                                    //         }
                                    //     }
                                    // }
                                    // countrySelectComponent={
                                    //     {
                                    //     }
                                    // }
                                    smartCaret={true}

                                />
                            </div>

                        </div>
                        <div>
                            <label for="subject" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Subject</label>
                            <input type="text" id="subject" class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 shadow-sm focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500 dark:shadow-sm-light" placeholder="Let us know how we can help you" required />
                        </div>
                    </div>
                    <div className="flex flex-col ">
                        <div className="">
                            <label for="subject" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Interested Product</label>

                            <div className="flex gap-2">

                                <div className="flex flex-row gap-2">
                                    <Radio
                                        id="bifold" name="type"
                                        ripple={false}
                                        className="hover:before:opacity-0"
                                        containerProps={{
                                            className: "p-0"
                                        }}
                                        defaultChecked
                                    />


                                    <Typography color="blue-gray" className="block mb-2 text-sm font-light text-gray-900 dark:text-white">Bifold</Typography>
                                </div>

                                <div className="flex flex-row gap-2 justify-items-center">
                                    <Radio
                                        id="other" name="type"
                                        ripple={false}
                                        className="hover:before:opacity-0"
                                        containerProps={{
                                            className: "p-0"
                                        }}
                                    />


                                    <Typography color="blue-gray" className="block mb-2 text-sm font-light text-gray-900 dark:text-white">Other</Typography>
                                </div>
                            </div>
                        </div>

                        <div class="h-full">
                            <label for="message" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-400">Your message</label>
                            <textarea id="message" rows="6" class="block p-2.5 w-full h-5/6 text-sm text-gray-900 bg-gray-50 rounded-lg shadow-sm border border-gray-300 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" placeholder="Leave a comment..."></textarea>
                        </div>
                    </div>
                </div>
                    <div className="flex justify-center ">

                        <button type="submit" class="mx-auto rounded-full bg-orange-900 justify-center py-3 px-5 text-sm font-medium text-center text-white  bg-primary-700 sm:w-fit hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">Send message</button>
                    </div>

            </form >
        </>
    )

}
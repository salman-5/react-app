import Form from "../utils/Form";
export default function Contact (){

    return(
        <div>
 <h2 class="underline decoration-amber-400 mb-4 text-4xl tracking-tight font-extrabold text-center text-gray-900 dark:text-black">Contact Us</h2>
      <p class="mb-8 lg:mb-16 font-light text-center text-gray-900 dark:text-gray-400 sm:text-xl">Got a technical issue? Want to send feedback about a beta feature? Need details about our Business plan? Let us know.</p>
        <div className="grid grid-cols-2">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15685.092247898185!2d76.1645033955574!3d10.635882070625502!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba7ea28929daa11%3A0xa0cc017c3827a1e8!2sToddy%20Shop%20Chungam!5e0!3m2!1sen!2sin!4v1684406121748!5m2!1sen!2sin" width="200" height="200" style={{ border: 0 }} allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"/>
        <Form/>
        </div>

        </div>

    );
}

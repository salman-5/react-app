import Filter from "../utils/Filter";

export default function Gallery(){

    return (
        <div className="">
            <Filter/>
        </div>

    );
}